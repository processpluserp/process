package areabajocurva;
import javax.swing.JOptionPane;
/**
 * 
 * @author Jair Gomez & Damian Mosquera  
 */

public class AreaBajoCurva{
   
    public static void main(String[] args){ 
      
        
        
        //recibe los datos de entrada por teclado
        AreaBajoCurva GenerarNumerosAleatorios=new AreaBajoCurva(); 
        AreaBajoCurva DespejeFunciones=new AreaBajoCurva();
        AreaBajoCurva CalculaElArea=new AreaBajoCurva();
        String semilla = JOptionPane.showInputDialog(null, "introduce semilla");
        double x = Integer.parseInt(semilla); 
        String multiplicador = JOptionPane.showInputDialog(null, "introduce El Multiplicador");
        double a = Integer.parseInt(multiplicador); 
        String constanteAditiva = JOptionPane.showInputDialog(null, "introduce La Constante Aditiva");
        double b = Integer.parseInt(constanteAditiva); 
        String modulo = JOptionPane.showInputDialog(null, "introduce Modulo");
        double m = Integer.parseInt(modulo);
        int mod = Integer.parseInt(modulo);
        //String intervalo1 = JOptionPane.showInputDialog(null, "introduce el primer intervalo");
        //double intervaloA = 0;//Integer.parseInt(intervalo1); 
        //String intervalo2 = JOptionPane.showInputDialog(null, "introduce el segundo intervalo");
        //double intervaloB = 2;//Integer.parseInt(intervalo2); 
        //String funcion = JOptionPane.showInputDialog(null, "Seleccione el tipo de funcion que desea ingresar: " +"\n"+ "1. Funcion Constante (y = a)" + "\n" + "2. Funcion Lineal (y = ax + b)"+ "\n" + "3. Funcion Cuadratica (y = ax² + bx + c)" + "\n" + "4. Funcion Cubica (y = ax³ + bx² + cx + d)" );
        //int numFuncion = Integer.parseInt(funcion);
         //inicializacion de variables
       
        double [][] coordenadas = new double[mod][4];
        String [][] coordenadasx = new String[mod][4];
        
        if(x!=0||a!=0||m!=0){
            GenerarNumerosAleatorios.GeneradorCongruencialMultiplicativo(x , a, b, m, coordenadas,coordenadasx);
            
        } 
    }
    public void GeneradorCongruencialMultiplicativo(double x, double a,double b,double m, double [][]coordenadas, String [][]coordenadasx){ 
        System.out.println("GENERA NUMEROS ALEATORIOS"+"\n"); 
        
        coordenadas[0][0] = x/m;
        System.out.println("xps" +x/m);
        for(int i=0;i<=(m-1);i++){ 
           //int val = i-1;
            double nval = 0;
            if(i == 0){
                nval =  x;
            }else{
                nval =  coordenadas[i-1][0]; 
            }
            x=((a*nval)+b)%m;
            coordenadas[i][0] = x;
            x=x/m;
            
            String temp = ""+x;
            String [] xtemp = temp.split("");
            for(int xx = 0;xx < 1;xx++ ){
                //System.out.println(xtemp[2]+ " -- "+xtemp[3] + " -- "+ xtemp[4] + " -- "+ xtemp[5]+ " -- "+ xtemp[6]);
                coordenadasx[i][0] = ""+x;
                //System.out.println("x"+i+" = "+x);
                
            }        
        }
        for(int xx = 0;xx < coordenadasx.length;xx++ ){
             if(xx < coordenadasx.length - 1 ){
                if(Double.parseDouble(coordenadasx[xx][0]) < Double.parseDouble(coordenadasx[xx +1][0])){
                      coordenadasx[xx][1] = ""+1;
                      //System.out.println(Double.parseDouble(coordenadasx[xx][0]) +" < "+Double.parseDouble(coordenadasx[xx +1][0]) + " 1");
                 }else{
                       coordenadasx[xx][1] = ""+0;
                       //System.out.println(Double.parseDouble(coordenadasx[xx][0]) +" < "+Double.parseDouble(coordenadasx[xx +1][0]) + " 0");
                 }
                
             } 
        }
        int corridas2 = 0;
        int corridas3 = 0;
        int corridas5 = 0;
        int corridas1 = 0;
        for(int xx = 0; xx < coordenadasx.length; xx++ ){
            if( xx == 0){
                if( xx < coordenadasx.length - 3){
                    if( Integer.parseInt(coordenadasx[xx][1])  == Integer.parseInt(coordenadasx[xx + 1][1])){
                        if( Integer.parseInt(coordenadasx[xx + 1][1])  == Integer.parseInt(coordenadasx[xx + 2][1])){
                            corridas3++;
                            System.out.println((coordenadasx[xx][1]) + " -> 3");
                        }else{
                            corridas2++;
                            System.out.println((coordenadasx[xx][1]) + " -> 2");
                        }
                    }else{
                        corridas1++;
                        System.out.println((coordenadasx[xx][1]) + " -> 1");
                    }
                }
            }
            
            else if( xx < coordenadasx.length - 3 && xx > 1){
                if( Integer.parseInt(coordenadasx[xx][1]) == Integer.parseInt(coordenadasx[xx - 1][1]) ){
                    if( Integer.parseInt(coordenadasx[xx - 1][1]) == Integer.parseInt(coordenadasx[xx - 2][1]) ){
                        corridas3++;
                        System.out.println((coordenadasx[xx][1]) + " -> 3");
                    }else{
                        corridas2++;
                        System.out.println((coordenadasx[xx][1]) + " -> 2");
                    }
                }else if(Integer.parseInt(coordenadasx[xx][1]) != Integer.parseInt(coordenadasx[xx - 1][1])){
                    if( Integer.parseInt(coordenadasx[xx][1]) == Integer.parseInt(coordenadasx[xx + 1][1]) ){
                        if( Integer.parseInt(coordenadasx[xx + 1][1]) == Integer.parseInt(coordenadasx[xx + 2][1]) ){
                            corridas3++;
                        System.out.println((coordenadasx[xx][1]) + " -> 3");
                        }else{
                            corridas2++;
                        System.out.println((coordenadasx[xx][1]) + " -> 2");
                        }
                    }else{
                        corridas1++;
                        System.out.println((coordenadasx[xx][1]) + " -> 1");
                    }
                    
                }
            }
            
            else if(xx == 1){
                if( Integer.parseInt(coordenadasx[xx][1]) == Integer.parseInt(coordenadasx[xx - 1][1]) ){
                    if( Integer.parseInt(coordenadasx[xx ][1]) == Integer.parseInt(coordenadasx[xx + 1][1]) ){
                        corridas3++;
                        System.out.println((coordenadasx[xx][1]) + " ->3");
                    }else{
                        corridas2++;
                        System.out.println((coordenadasx[xx][1]) + " -> 2");
                    }
                }else{
                    corridas2++;
                    System.out.println((coordenadasx[xx][1]) + " -> 1");
                }
            }
            
        }
        System.out.println(corridas1);
        for(int xx = 0;xx < coordenadasx.length;xx++ ){
             //System.out.println((coordenadasx[xx][1]));
             //System.out.println(coordenadas[xx][0] + " -- "+ coordenadas[xx][1]);
        }
        System.out.println("TERMINO");
        System.out.println("----------------------------------------------------------------------------------------"+"\n");
    }
    
   
}
    
    

    
